package interfaces;

import javax.swing.JPanel;

/**
 * 
 * @author Manuel Glantschnig
 * @version 1.0
 */
public interface ILabyrinth
{
	JPanel jPanelOben1 = new JPanel();
	JPanel jPanelOben2 = new JPanel();
	JPanel jPanelOben3 = new JPanel();
	JPanel jPanelOben4 = new JPanel();
	JPanel jPanelOben5 = new JPanel();
	JPanel jPanelOben6 = new JPanel();
	JPanel jPanelOben7 = new JPanel();
	JPanel jPanelOben8 = new JPanel();
	JPanel jPanelOben9 = new JPanel();
	JPanel jPanelOben10= new JPanel();
	JPanel jPanelOben11= new JPanel();
	JPanel jPanelOben12= new JPanel();
	JPanel jPanelOben13= new JPanel();
	JPanel jPanelOben14= new JPanel();
	JPanel jPanelOben15= new JPanel();
	JPanel jPanelOben16= new JPanel();
	JPanel jPanelOben17= new JPanel();
	JPanel jPanelOben18= new JPanel();
	JPanel jPanelOben19= new JPanel();
	JPanel jPanelOben20= new JPanel();
	JPanel jPanelOben21= new JPanel();
	JPanel jPanelOben22= new JPanel();
	JPanel jPanelOben23= new JPanel();
	JPanel jPanelOben24= new JPanel();
	JPanel jPanelOben25= new JPanel();
	JPanel jPanelOben26= new JPanel();
	JPanel jPanelOben27= new JPanel();
	JPanel jPanelOben28= new JPanel();
	JPanel jPanelOben29= new JPanel();
	JPanel jPanelOben30= new JPanel();
	JPanel jPanelOben31= new JPanel();
	JPanel jPanelOben32= new JPanel();
	JPanel jPanelOben33= new JPanel();
}
