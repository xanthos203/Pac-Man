package view;

public class CMuenzendarstellen 
{
	public CMuenzendarstellen()
	{
		
	}
	
	public void Muenzendarstellen() 
	{
		
	}
}